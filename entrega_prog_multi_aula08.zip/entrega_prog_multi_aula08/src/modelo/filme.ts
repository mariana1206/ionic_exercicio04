export class Filme{
    id: number;
    nome: string;
    lancamento: string;
    popularidade: string;
    }